export interface Product{
   id?: number // interrogação é pra informar que  a id não vai ser sempre obrigatória
   name: string 
   price: number 
}